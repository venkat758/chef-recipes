maintainer        "Joshua Sierles"
maintainer_email  "joshua@diluvia.net"
description       "Configures timezone"
version           "0.2"
