default.syslog_ng[:root] = "/u/logs"
default.syslog_ng[:target_host] = '10.10.0.13'
default.syslog_ng[:default_host] = '10.10.0.13'
