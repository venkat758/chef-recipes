runit_sv_bin "/usr/bin/sv"

runit_service_dir "/etc/service"
runit_sv_dir "/etc/sv"
