maintainer        "Joshua Sierles"
maintainer_email  "joshua@diluvia.net"
description       "Configures runit"
version           "0.1"