maintainer        "Joshua Sierles"
maintainer_email  "joshua@diluvia.net"
description       "Installs bluepill and provides definitions and templates for monitoring"
version           "0.8"