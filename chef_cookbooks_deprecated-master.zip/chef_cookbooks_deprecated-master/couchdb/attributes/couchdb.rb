default.couchdb[:max_document_size] = "4294967296"
default.couchdb[:port] = "5984"
default.couchdb[:bind_address] = "127.0.0.1"
