maintainer        "Joshua Sierles"
maintainer_email  "joshua@diluvia.net"
description       "Configures keepalived"
version           "0.2"