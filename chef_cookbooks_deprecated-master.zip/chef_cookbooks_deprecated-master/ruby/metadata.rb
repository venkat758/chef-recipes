maintainer        "Joshua Sierles"
maintainer_email  "joshua@diluvia.net"
description       "Configures ruby"
version           "0.2"
