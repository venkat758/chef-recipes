maintainer        "Joshua Sierles"
maintainer_email  "joshua@diluvia.net"
description       "Installs java"
version           "0.0.1"
