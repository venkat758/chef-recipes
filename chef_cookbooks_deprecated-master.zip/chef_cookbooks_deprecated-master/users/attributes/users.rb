# Set to false if using NFS-based home directories
default.users[:manage_files] = true
