template "/etc/security/limits.conf" do
  owner "root"
  group "root"
  mode 0644
end