maintainer        "Joshua Sierles"
maintainer_email  "joshua@diluvia.net"
description       "Ruby shadow"
version           "2.3.14"
