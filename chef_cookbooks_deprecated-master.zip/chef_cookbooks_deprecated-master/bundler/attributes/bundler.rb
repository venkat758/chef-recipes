default.bundler[:version] = '1.0.18'
