gem_package "bundler" do
  version node[:bundler][:version]
end